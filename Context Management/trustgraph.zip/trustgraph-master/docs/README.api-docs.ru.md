---
layout: default
title: "Автоматическое создание документации"
parent: "Russian (Beta)"
---

# Автоматическое создание документации

> **Beta Translation:** This document was translated via Machine Learning and as such may not be 100% accurate. All non-English languages are currently classified as Beta.

## Документация REST и WebSocket API

- `specs/build-docs.sh` - Создает документацию для REST и WebSocket API на основе спецификаций OpenAPI и AsyncAPI.

## Документация Python API

Документация Python API генерируется из docstrings с использованием пользовательского скрипта Python, который анализирует пакет `trustgraph.api`.

### Требования

Пакет `trustgraph` должен быть импортируемым. Если вы работаете в среде разработки:

```bash
cd trustgraph-base
pip install -e .
```

### Генерация документации

Из каталога `docs`:

```bash
cd docs
python3 generate-api-docs.py > python-api.md
```

Это создает один файл Markdown с полной документацией API, в котором показаны:
- Инструкции по установке и быстрому запуску
- Заявления импорта для каждого класса/типа
- Полные docstrings с примерами
- Содержание, организованное по категориям

### Стиль документации

Все docstrings следуют формату Google-style:
- Краткое однострочное описание
- Подробное описание
- Раздел "Args" с описаниями параметров
- Раздел "Returns"
- Раздел "Raises" (при необходимости)
- Блоки с примерами кода с правильной подсветкой синтаксиса

Сгенерированная документация отображает публичный API точно так, как его импортируют из `trustgraph.api`, не раскрывая внутреннюю структуру модуля.
