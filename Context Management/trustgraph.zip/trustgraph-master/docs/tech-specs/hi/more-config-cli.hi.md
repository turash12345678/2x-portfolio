---
layout: default
title: "अधिक कॉन्फ़िगरेशन CLI तकनीकी विनिर्देश"
parent: "Hindi (Beta)"
---

```hindi
# अधिक कॉन्फ़िगरेशन CLI तकनीकी विनिर्देश

> **Beta Translation:** This document was translated via Machine Learning and as such may not be 100% accurate. All non-English languages are currently classified as Beta.

## अवलोकन

यह विनिर्देश TrustGraph के लिए उन्नत कमांड-लाइन कॉन्फ़िगरेशन क्षमताओं का वर्णन करता है, जो उपयोगकर्ताओं को दानेदार CLI कमांड के माध्यम से व्यक्तिगत कॉन्फ़िगरेशन आइटम प्रबंधित करने की अनुमति देता है। यह एकीकरण चार प्राथमिक उपयोग मामलों का समर्थन करता है:

1. **कॉन्फ़िगरेशन आइटमों की सूची**: किसी विशिष्ट प्रकार की कॉन्फ़िगरेशन कुंजियों का प्रदर्शन करें।
2. **कॉन्फ़िगरेशन आइटम प्राप्त करें**: विशिष्ट कॉन्फ़िगरेशन मान पुनः प्राप्त करें।
3. **कॉन्फ़िगरेशन आइटम सेट करें**: व्यक्तिगत कॉन्फ़िगरेशन आइटम सेट या अपडेट करें।
4. **कॉन्फ़िगरेशन आइटम हटाएं**: विशिष्ट कॉन्फ़िगरेशन आइटम हटाएं।

## लक्ष्य

- **बारीक नियंत्रण**: व्यक्तिगत कॉन्फ़िगरेशन आइटमों के प्रबंधन को सक्षम करें, न कि बल्क ऑपरेशनों को।
- **प्रकार-आधारित सूची**: उपयोगकर्ताओं को कॉन्फ़िगरेशन आइटमों को प्रकार के अनुसार ब्राउज़ करने की अनुमति दें।
- **एकल आइटम संचालन**: व्यक्तिगत कॉन्फ़िगरेशन आइटमों के लिए प्राप्त/सेट/हटाने के कमांड प्रदान करें।
- **API एकीकरण**: सभी परिचालनों के लिए मौजूदा कॉन्फ़िगरेशन API का उपयोग करें।
- **संगत CLI पैटर्न**: स्थापित TrustGraph CLI कन्वेंशन और पैटर्न का पालन करें।
- **त्रुटि प्रबंधन**: अमान्य परिचालनों के लिए स्पष्ट त्रुटि संदेश प्रदान करें।
- **JSON आउटपुट**: प्रोग्रामेटिक उपयोग के लिए संरचित आउटपुट का समर्थन करें।
- **प्रलेखन**: व्यापक सहायता और उपयोग उदाहरण शामिल करें।

## पृष्ठभूमि

TrustGraph वर्तमान में कॉन्फ़िगरेशन API और एक एकल CLI कमांड `tg-show-config` के माध्यम से कॉन्फ़िगरेशन प्रबंधन प्रदान करता है जो संपूर्ण कॉन्फ़िगरेशन प्रदर्शित करता है। जबकि यह कॉन्फ़िगरेशन देखने के लिए उपयोगी है, यह दानेदार प्रबंधन क्षमताओं की कमी है।

वर्तमान सीमाएँ शामिल हैं:
- CLI से प्रकार के अनुसार कॉन्फ़िगरेशन आइटमों की सूची बनाने का कोई तरीका नहीं है।
- विशिष्ट कॉन्फ़िगरेशन मान पुनः प्राप्त करने के लिए कोई CLI कमांड नहीं है।
- व्यक्तिगत कॉन्फ़िगरेशन आइटमों को सेट करने के लिए कोई CLI कमांड नहीं है।
- विशिष्ट कॉन्फ़िगरेशन आइटमों को हटाने के लिए कोई CLI कमांड नहीं है।

यह विनिर्देश इन कमियों को चार नए CLI कमांड जोड़कर संबोधित करता है जो दानेदार कॉन्फ़िगरेशन प्रबंधन प्रदान करते हैं। TrustGraph, CLI कमांड के माध्यम से व्यक्तिगत कॉन्फ़िगरेशन API परिचालनों को उजागर करके:
- स्क्रिप्टेड कॉन्फ़िगरेशन प्रबंधन को सक्षम करें।
- प्रकार के अनुसार कॉन्फ़िगरेशन संरचना की खोज की अनुमति दें।
- लक्षित कॉन्फ़िगरेशन अपडेट का समर्थन करें।
- कॉन्फ़िगरेशन नियंत्रण का महीन स्तर प्रदान करें।

## तकनीकी डिजाइन

### आर्किटेक्चर

उन्नत CLI कॉन्फ़िगरेशन के लिए निम्नलिखित तकनीकी घटकों की आवश्यकता होती है:

1. **tg-list-config-items**
   - एक निर्दिष्ट प्रकार के लिए कॉन्फ़िगरेशन कुंजियों की सूची बनाता है।
   - `Config.list(type)` API विधि को कॉल करता है।
   - कॉन्फ़िगरेशन कुंजियों की सूची आउटपुट करता है।

   मॉड्यूल: `trustgraph.cli.list_config_items`

2. **tg-get-config-item**
   - विशिष्ट कॉन्फ़िगरेशन आइटम(ों) को पुनः प्राप्त करता है।
   - `Config.get(keys)` API विधि को कॉल करता है।
   - कॉन्फ़िगरेशन मानों को JSON प्रारूप में आउटपुट करता है।

   मॉड्यूल: `trustgraph.cli.get_config_item`

3. **tg-put-config-item**
   - एक कॉन्फ़िगरेशन आइटम सेट या अपडेट करता है।
   - `Config.put(values)` API विधि को कॉल करता है।
   - प्रकार, कुंजी और मान पैरामीटर स्वीकार करता है।

   मॉड्यूल: `trustgraph.cli.put_config_item`

4. **tg-delete-config-item**
   - एक कॉन्फ़िगरेशन आइटम हटाता है।
   - `Config.delete(keys)` API विधि को कॉल करता है।
   - प्रकार और कुंजी पैरामीटर स्वीकार करता है।

   मॉड्यूल: `trustgraph.cli.delete_config_item`

### डेटा मॉडल

#### ConfigKey और ConfigValue

कमांड `trustgraph.api.types` से मौजूदा डेटा संरचनाओं का उपयोग करते हैं:

```python
@dataclasses.dataclass
class ConfigKey:
    type : str
    key : str

@dataclasses.dataclass
class ConfigValue:
    type : str
    key : str
    value : str
```

यह दृष्टिकोण अनुमति देता है:
- CLI और API में सुसंगत डेटा प्रबंधन।
- प्रकार-सुरक्षित कॉन्फ़िगरेशन संचालन।
- संरचित इनपुट/आउटपुट प्रारूप।
- मौजूदा कॉन्फ़िगरेशन API के साथ एकीकरण।

### CLI कमांड विनिर्देश

#### tg-list-config-items
```bash
tg-list-config-items --type <config-type> [--format text|json] [--api-url <url>]
```
- **उद्देश्य**: एक दिए गए प्रकार के सभी कॉन्फ़िगरेशन कुंजियों की सूची बनाएं।
- **API कॉल**: `Config.list(type)`
- **आउटपुट**:
  - `text` (डिफ़ॉल्ट): कॉन्फ़िगरेशन कुंजियाँ नई पंक्तियों से अलग की गई हैं।
  - `json`: कॉन्फ़िगरेशन कुंजियों की JSON सरणी।

#### tg-get-config-item
```bash
tg-get-config-item --type <type> --key <key> [--format text|json] [--api-url <url>]
```
- **उद्देश्य**: एक विशिष्ट कॉन्फ़िगरेशन आइटम पुनः प्राप्त करें।
- **API कॉल**: `Config.get([ConfigKey(type, key)])`
- **आउटपुट**:
  - `text` (डिफ़ॉल्ट): कच्चा स्ट्रिंग मान।
  - `json`: JSON-एन्कोडेड स्ट्रिंग मान।

#### tg-put-config-item
```bash
tg-put-config-item --type <type> --key <key> --value <value> [--api-url <url>]
tg-put-config-item --type <type> --key <key> --stdin [--api-url <url>]
```
- **उद्देश्य**: एक कॉन्फ़िगरेशन आइटम सेट करें।
- **API कॉल**: `Config.put(values)`
- **पैरामीटर**: प्रकार, कुंजी और मान।
- **इनपुट**: कमांड लाइन या stdin के माध्यम से।

#### tg-delete-config-item
```bash
tg-delete-config-item --type prompt --key old-template
```
- **उद्देश्य**: एक कॉन्फ़िगरेशन आइटम हटाएं।
- **API कॉल**: `Config.delete(keys)`
- **पैरामीटर**: प्रकार और कुंजी।

## उपयोग उदाहरण

#### कॉन्फ़िगरेशन आइटमों की सूची
```bash
# प्रॉम्प्ट कुंजियों की सूची (टेक्स्ट प्रारूप)
tg-list-config-items --type prompt
template-1
template-2
system-prompt

# प्रॉम्प्ट कुंजियों की सूची (JSON प्रारूप)
tg-list-config-items --type prompt --format json
["template-1", "template-2", "system-prompt"]
```

#### कॉन्फ़िगरेशन आइटम प्राप्त करें
```bash
# प्रॉम्प्ट मान प्राप्त करें (टेक्स्ट प्रारूप)
tg-get-config-item --type prompt --key template-1
You are a helpful assistant. Please respond to: {query}

# प्रॉम्प्ट मान प्राप्त करें (JSON प्रारूप)
tg-get-config-item --type prompt --key template-1 --format json
"You are a helpful assistant. Please respond to: {query}"
```

#### कॉन्फ़िगरेशन आइटम सेट करें
```bash
# कमांड लाइन से सेट करें
tg-put-config-item --type prompt --key new-template --value "Custom prompt: {input}"

# फ़ाइल से पाइप के माध्यम से सेट करें
cat ./prompt-template.txt | tg-put-config-item --type prompt --key complex-template --stdin

# फ़ाइल से रीडायरेक्ट के माध्यम से सेट करें
tg-put-config-item --type prompt --key complex-template --stdin < ./prompt-template.txt

# कमांड आउटपुट से सेट करें
echo "Generated template: {query}" | tg-put-config-item --type prompt --key auto-template --stdin
```

#### कॉन्फ़िगरेशन आइटम हटाएं
```bash
tg-delete-config-item --type prompt --key old-template
```

## खुले प्रश्न

- क्या कमांड एकल आइटमों के अलावा बैच संचालन (एकाधिक कुंजियाँ) का समर्थन करना चाहिए?
- सफलता की पुष्टि के लिए किस आउटपुट प्रारूप का उपयोग किया जाना चाहिए?
- उपयोगकर्ताओं द्वारा कॉन्फ़िगरेशन प्रकारों का दस्तावेजीकरण/खोज कैसे किया जाना चाहिए?

## संदर्भ

- मौजूदा कॉन्फ़िगरेशन API: `trustgraph/api/config.py`
- CLI पैटर्न: `trustgraph-cli/trustgraph/cli/show_config.py`
- डेटा प्रकार: `trustgraph/api/types.py`
